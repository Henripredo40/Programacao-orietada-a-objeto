package dao;

import modelo.*;
import java.util.ArrayList;
import java.util.List;

public class BancoDeDados {
    public static List<Aluno> alunos = new ArrayList<>();
    public static List<Professor> professores = new ArrayList<>();
    public static List<Materia> materias = new ArrayList<>();
    public static List<Atividade> atividades = new ArrayList<>();
    public static List<Correcao> correcoes = new ArrayList<>();
    public static List<Matricula> matriculas = new ArrayList<>();
}